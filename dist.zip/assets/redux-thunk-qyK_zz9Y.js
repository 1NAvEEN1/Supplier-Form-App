function e(t){return({dispatch:n,getState:u})=>a=>r=>typeof r=="function"?r(n,u,t):a(r)}var i=e(),w=e;export{i as t,w};
